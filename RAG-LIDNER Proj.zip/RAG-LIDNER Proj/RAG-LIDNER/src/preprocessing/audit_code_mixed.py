from pathlib import Path
import re
import json
import pandas as pd


INPUT_FILE = Path(
    "data/raw/author_code_mixed/"
    "Kokborok Code-mixed dataset.txt"
)

OUTPUT_DIR = Path("data/metadata")

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


def normalize_text(text):
    """
    Normalize whitespace without changing
    the actual linguistic content.
    """

    text = re.sub(
        r"\s+",
        " ",
        text
    ).strip()

    return text


def tokenize(text):
    """
    Simple whitespace/punctuation-aware
    tokenization for initial corpus statistics.
    """

    return re.findall(
        r"\b[\w'-]+\b",
        text,
        flags=re.UNICODE
    )


def load_dataset():

    records = []

    with open(
        INPUT_FILE,
        "r",
        encoding="utf-8"
    ) as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            # Expected format:
            # 1.Some sentence

            match = re.match(
                r"^(\d+)\.\s*(.*)$",
                line
            )

            if match:

                sentence_id = int(
                    match.group(1)
                )

                text = match.group(2).strip()

                records.append(
                    {
                        "sentence_id": sentence_id,
                        "text": text
                    }
                )

    return records


def main():

    print("=" * 70)
    print("RAG-LIDNER CODE-MIXED DATASET AUDIT")
    print("=" * 70)

    if not INPUT_FILE.exists():

        raise FileNotFoundError(
            f"Dataset not found:\n{INPUT_FILE}"
        )

    records = load_dataset()

    df = pd.DataFrame(records)

    print()
    print("Dataset:", INPUT_FILE)
    print("Records:", len(df))

    # --------------------------------------------------
    # BASIC VALIDATION
    # --------------------------------------------------

    df["normalized_text"] = (
        df["text"]
        .apply(normalize_text)
    )

    df["tokens"] = (
        df["normalized_text"]
        .apply(tokenize)
    )

    df["token_count"] = (
        df["tokens"]
        .apply(len)
    )

    print()
    print("=" * 70)
    print("VALIDATION")
    print("=" * 70)

    print(
        "Missing IDs:",
        df["sentence_id"].isna().sum()
    )

    print(
        "Missing text:",
        df["text"].isna().sum()
    )

    print(
        "Empty text:",
        (df["normalized_text"] == "").sum()
    )

    print(
        "Duplicate sentence IDs:",
        df["sentence_id"].duplicated().sum()
    )

    print(
        "Duplicate sentences:",
        df["normalized_text"].duplicated().sum()
    )

    # --------------------------------------------------
    # ID RANGE
    # --------------------------------------------------

    print()
    print("=" * 70)
    print("ID RANGE")
    print("=" * 70)

    print(
        "Minimum ID:",
        df["sentence_id"].min()
    )

    print(
        "Maximum ID:",
        df["sentence_id"].max()
    )

    expected_ids = set(
        range(
            df["sentence_id"].min(),
            df["sentence_id"].max() + 1
        )
    )

    actual_ids = set(
        df["sentence_id"]
    )

    missing_ids = sorted(
        expected_ids - actual_ids
    )

    print(
        "Missing IDs:",
        missing_ids
    )

    # --------------------------------------------------
    # TOKEN STATISTICS
    # --------------------------------------------------

    print()
    print("=" * 70)
    print("TOKEN STATISTICS")
    print("=" * 70)

    print(
        "Total tokens:",
        df["token_count"].sum()
    )

    print(
        "Average tokens:",
        df["token_count"].mean()
    )

    print(
        "Median tokens:",
        df["token_count"].median()
    )

    print(
        "Minimum tokens:",
        df["token_count"].min()
    )

    print(
        "Maximum tokens:",
        df["token_count"].max()
    )

    print(
        "Vocabulary size:",
        len(
            set(
                token.lower()
                for tokens in df["tokens"]
                for token in tokens
            )
        )
    )

    # --------------------------------------------------
    # DUPLICATES
    # --------------------------------------------------

    duplicates = (
        df[
            df["normalized_text"].duplicated(
                keep=False
            )
        ]
        .sort_values("normalized_text")
    )

    print()
    print("=" * 70)
    print("DUPLICATES")
    print("=" * 70)

    print(
        "Duplicate rows:",
        len(duplicates)
    )

    if len(duplicates) > 0:

        print(
            duplicates[
                [
                    "sentence_id",
                    "text"
                ]
            ]
            .head(20)
            .to_string(index=False)
        )

    # --------------------------------------------------
    # SAVE AUDIT DATA
    # --------------------------------------------------

    audit_csv = (
        OUTPUT_DIR /
        "code_mixed_dataset_audit.csv"
    )

    df[
        [
            "sentence_id",
            "text",
            "normalized_text",
            "token_count"
        ]
    ].to_csv(
        audit_csv,
        index=False,
        encoding="utf-8"
    )

    statistics = {

        "dataset": str(INPUT_FILE),

        "records": len(df),

        "minimum_id": int(
            df["sentence_id"].min()
        ),

        "maximum_id": int(
            df["sentence_id"].max()
        ),

        "missing_ids": missing_ids,

        "missing_text": int(
            df["text"].isna().sum()
        ),

        "empty_text": int(
            (df["normalized_text"] == "").sum()
        ),

        "duplicate_sentence_ids": int(
            df["sentence_id"].duplicated().sum()
        ),

        "duplicate_sentences": int(
            df["normalized_text"].duplicated().sum()
        ),

        "total_tokens": int(
            df["token_count"].sum()
        ),

        "average_tokens": float(
            df["token_count"].mean()
        ),

        "median_tokens": float(
            df["token_count"].median()
        ),

        "minimum_tokens": int(
            df["token_count"].min()
        ),

        "maximum_tokens": int(
            df["token_count"].max()
        ),

        "vocabulary_size": len(
            set(
                token.lower()
                for tokens in df["tokens"]
                for token in tokens
            )
        )
    }

    json_file = (
        OUTPUT_DIR /
        "code_mixed_dataset_statistics.json"
    )

    with open(
        json_file,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            statistics,
            f,
            indent=4,
            ensure_ascii=False
        )

    print()
    print("=" * 70)
    print("FILES SAVED")
    print("=" * 70)

    print(
        "Audit CSV:",
        audit_csv
    )

    print(
        "Statistics:",
        json_file
    )

    print()
    print("AUDIT COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()