from pathlib import Path
import requests


SEARCH_URLS = [
    "https://huggingface.co/api/datasets?search=Kokborok",
    "https://huggingface.co/api/models?search=Kokborok"
]


def search_huggingface(url):

    print("=" * 70)
    print("SEARCHING")
    print(url)
    print("=" * 70)

    response = requests.get(
        url,
        timeout=30
    )

    response.raise_for_status()

    data = response.json()

    for item in data[:20]:

        print(
            item.get(
                "id",
                "UNKNOWN"
            )
        )


def main():

    for url in SEARCH_URLS:

        try:

            search_huggingface(url)

        except Exception as e:

            print(
                "ERROR:",
                e
            )


if __name__ == "__main__":
    main()