from pathlib import Path
import pandas as pd


INPUT_FILE = Path(
    "data/annotations/batches/"
    "code_mixed_token_annotations.csv"
)

OUTPUT_DIR = Path(
    "data/annotations/batches"
)

BATCH_SIZE = 100


def main():

    print("=" * 70)
    print("RAG-LIDNER ANNOTATION BATCH GENERATOR")
    print("=" * 70)

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found:\n{INPUT_FILE}"
        )

    df = pd.read_csv(
        INPUT_FILE,
        keep_default_na=False
    )

    print(
        f"\nLoaded tokens: {len(df)}"
    )

    # -----------------------------------------------------
    # Convert token rows into sentence-level records
    # -----------------------------------------------------

    sentences = []

    for sentence_id, group in df.groupby(
        "sentence_id",
        sort=True
    ):

        group = group.sort_values(
            "token_id"
        )

        tokens = group["token"].tolist()

        candidate_labels = (
            group["lid_candidate"].tolist()
        )

        sentence = " ".join(tokens)

        sentences.append(
            {
                "sentence_id": sentence_id,
                "text": sentence,
                "tokens": " ".join(tokens),
                "candidate_lid": " ".join(
                    candidate_labels
                ),
                "lid_verified": "",
                "ner_verified": "",
                "annotator": "",
                "notes": "",
            }
        )

    sentence_df = pd.DataFrame(
        sentences
    )

    print(
        f"Sentences: {len(sentence_df)}"
    )

    # -----------------------------------------------------
    # Create batches
    # -----------------------------------------------------

    number_of_batches = (
        len(sentence_df) + BATCH_SIZE - 1
    ) // BATCH_SIZE

    print(
        f"Batches: {number_of_batches}"
    )

    for batch_number in range(
        number_of_batches
    ):

        start = (
            batch_number * BATCH_SIZE
        )

        end = start + BATCH_SIZE

        batch = sentence_df.iloc[
            start:end
        ].copy()

        batch_id = (
            batch_number + 1
        )

        output_file = (
            OUTPUT_DIR /
            f"batch_{batch_id:03d}.csv"
        )

        batch.to_csv(
            output_file,
            index=False,
            encoding="utf-8"
        )

        print(
            f"Saved: {output_file}"
        )

    # -----------------------------------------------------
    # Save master sentence file
    # -----------------------------------------------------

    master_file = (
        OUTPUT_DIR /
        "code_mixed_sentence_annotations.csv"
    )

    sentence_df.to_csv(
        master_file,
        index=False,
        encoding="utf-8"
    )

    print(
        f"\nSaved master file: {master_file}"
    )

    print("\n" + "=" * 70)
    print("BATCH GENERATION COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()