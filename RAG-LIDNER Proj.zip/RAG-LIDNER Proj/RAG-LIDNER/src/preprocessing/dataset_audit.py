import json
import re
from pathlib import Path
from collections import Counter

import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]

RAW_DIR = PROJECT_ROOT / "data" / "raw" / "kokborok_digitalisation"
OUTPUT_DIR = PROJECT_ROOT / "data" / "metadata"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# TOKENIZATION
# ============================================================

def tokenize(text):
    """
    Simple whitespace + punctuation aware tokenizer.

    This is only for corpus statistics.
    It is NOT our final NLP tokenizer.
    """

    if not isinstance(text, str):
        return []

    tokens = re.findall(
        r"\b[\w'-]+\b",
        text,
        flags=re.UNICODE
    )

    return tokens


# ============================================================
# BASIC TEXT STATISTICS
# ============================================================

def text_statistics(texts, language_name):
    """
    Calculate corpus statistics for a list of sentences.
    """

    valid_texts = [
        text.strip()
        for text in texts
        if isinstance(text, str) and text.strip()
    ]

    tokenized = [
        tokenize(text)
        for text in valid_texts
    ]

    token_counts = [
        len(tokens)
        for tokens in tokenized
    ]

    vocabulary = set()

    for tokens in tokenized:
        vocabulary.update(
            token.lower()
            for token in tokens
        )

    statistics = {
        "language": language_name,
        "sentences": len(valid_texts),
        "tokens": sum(token_counts),
        "vocabulary_size": len(vocabulary),
        "average_tokens_per_sentence": (
            sum(token_counts) / len(token_counts)
            if token_counts else 0
        ),
        "minimum_tokens": (
            min(token_counts)
            if token_counts else 0
        ),
        "maximum_tokens": (
            max(token_counts)
            if token_counts else 0
        ),
        "unique_sentences": len(set(valid_texts)),
        "duplicate_sentences": (
            len(valid_texts) - len(set(valid_texts))
        ),
    }

    return statistics


# ============================================================
# LOAD smoldoc
# ============================================================

def load_smoldoc():

    path = RAW_DIR / "smoldoc__en_trp.json"

    print("\nLoading:", path)

    with path.open(
        "r",
        encoding="utf-8"
    ) as f:
        data = json.load(f)

    print("Documents:", len(data))

    english_sentences = []
    kokborok_sentences = []

    malformed_records = 0

    for record in data:

        srcs = record.get("srcs", [])
        trgs = record.get("trgs", [])

        if not isinstance(srcs, list):
            malformed_records += 1
            continue

        if not isinstance(trgs, list):
            malformed_records += 1
            continue

        if len(srcs) != len(trgs):
            print(
                "WARNING: source/target mismatch:",
                record.get("id")
            )

        english_sentences.extend(srcs)
        kokborok_sentences.extend(trgs)

    return (
        data,
        english_sentences,
        kokborok_sentences,
        malformed_records
    )


# ============================================================
# LOAD smolsent
# ============================================================

def load_smolsent():

    path = RAW_DIR / "smolsent__en_trp.json"

    print("\nLoading:", path)

    with path.open(
        "r",
        encoding="utf-8"
    ) as f:
        data = json.load(f)

    print("Sentence records:", len(data))

    english_sentences = []
    kokborok_sentences = []

    malformed_records = 0

    for record in data:

        src = record.get("src")
        trg = record.get("trg")

        if not isinstance(src, str):
            malformed_records += 1
            continue

        if not isinstance(trg, str):
            malformed_records += 1
            continue

        english_sentences.append(src)
        kokborok_sentences.append(trg)

    return (
        data,
        english_sentences,
        kokborok_sentences,
        malformed_records
    )


# ============================================================
# DUPLICATE ANALYSIS
# ============================================================

def duplicate_report(texts, name):

    normalized = [
        text.strip().lower()
        for text in texts
        if isinstance(text, str)
        and text.strip()
    ]

    counts = Counter(normalized)

    duplicates = {
        text: count
        for text, count in counts.items()
        if count > 1
    }

    print("\n" + "=" * 70)
    print(f"DUPLICATE ANALYSIS: {name}")
    print("=" * 70)

    print("Total sentences:", len(normalized))
    print("Unique sentences:", len(counts))
    print("Duplicated sentence forms:", len(duplicates))
    print(
        "Duplicate occurrences:",
        sum(count - 1 for count in duplicates.values())
    )

    if duplicates:

        print("\nTop duplicates:")

        for text, count in sorted(
            duplicates.items(),
            key=lambda x: x[1],
            reverse=True
        )[:10]:

            print(f"[{count}x] {text[:150]}")


# ============================================================
# LANGUAGE PAIR ANALYSIS
# ============================================================

def language_pair_report():

    print("\n" + "=" * 70)
    print("LANGUAGE PAIR ANALYSIS")
    print("=" * 70)

    files = [
        "smoldoc__en_trp.json",
        "smolsent__en_trp.json",
    ]

    rows = []

    for filename in files:

        path = RAW_DIR / filename

        with path.open(
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        counter = Counter()

        for record in data:

            sl = record.get("sl")
            tl = record.get("tl")

            counter[(sl, tl)] += 1

        for (source, target), count in counter.items():

            rows.append({
                "file": filename,
                "source_language": source,
                "target_language": target,
                "records": count
            })

    df = pd.DataFrame(rows)

    print(df.to_string(index=False))

    return df


# ============================================================
# SAVE SAMPLE DATA
# ============================================================

def save_samples(
    english_sentences,
    kokborok_sentences
):

    rows = []

    number = min(
        len(english_sentences),
        len(kokborok_sentences)
    )

    for i in range(
        min(number, 20)
    ):

        rows.append({
            "id": i,
            "english": english_sentences[i],
            "kokborok": kokborok_sentences[i]
        })

    df = pd.DataFrame(rows)

    output = OUTPUT_DIR / "translation_samples.csv"

    df.to_csv(
        output,
        index=False,
        encoding="utf-8-sig"
    )

    print(
        "\nSaved sample file:",
        output
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("RAG-LIDNER DATASET AUDIT")
    print("=" * 70)

    # --------------------------------------------------------
    # SMOLDOC
    # --------------------------------------------------------

    (
        smoldoc,
        doc_en,
        doc_kok,
        doc_malformed
    ) = load_smoldoc()

    print(
        "\nSMOLDOC sentence pairs:",
        min(
            len(doc_en),
            len(doc_kok)
        )
    )

    print(
        "Malformed documents:",
        doc_malformed
    )

    # --------------------------------------------------------
    # SMOLSENT
    # --------------------------------------------------------

    (
        smolsent,
        sent_en,
        sent_kok,
        sent_malformed
    ) = load_smolsent()

    print(
        "\nSMOLSENT sentence pairs:",
        min(
            len(sent_en),
            len(sent_kok)
        )
    )

    print(
        "Malformed records:",
        sent_malformed
    )

    # --------------------------------------------------------
    # COMBINE
    # --------------------------------------------------------

    english_all = doc_en + sent_en
    kokborok_all = doc_kok + sent_kok

    print("\n" + "=" * 70)
    print("COMBINED CORPUS")
    print("=" * 70)

    print(
        "English sentences:",
        len(english_all)
    )

    print(
        "Kokborok sentences:",
        len(kokborok_all)
    )

    # --------------------------------------------------------
    # STATISTICS
    # --------------------------------------------------------

    english_stats = text_statistics(
        english_all,
        "English"
    )

    kokborok_stats = text_statistics(
        kokborok_all,
        "Kokborok"
    )

    statistics_df = pd.DataFrame([
        english_stats,
        kokborok_stats
    ])

    print("\n" + "=" * 70)
    print("CORPUS STATISTICS")
    print("=" * 70)

    print(
        statistics_df.to_string(
            index=False
        )
    )

    # --------------------------------------------------------
    # SAVE STATISTICS
    # --------------------------------------------------------

    statistics_output = (
        OUTPUT_DIR /
        "kokborok_corpus_statistics.csv"
    )

    statistics_df.to_csv(
        statistics_output,
        index=False
    )

    print(
        "\nSaved:",
        statistics_output
    )

    # --------------------------------------------------------
    # DUPLICATES
    # --------------------------------------------------------

    duplicate_report(
        english_all,
        "English"
    )

    duplicate_report(
        kokborok_all,
        "Kokborok"
    )

    # --------------------------------------------------------
    # LANGUAGE PAIRS
    # --------------------------------------------------------

    language_df = language_pair_report()

    language_output = (
        OUTPUT_DIR /
        "language_pair_statistics.csv"
    )

    language_df.to_csv(
        language_output,
        index=False
    )

    # --------------------------------------------------------
    # SAMPLES
    # --------------------------------------------------------

    save_samples(
        english_all,
        kokborok_all
    )

    # --------------------------------------------------------
    # SUMMARY JSON
    # --------------------------------------------------------

    summary = {
        "smoldoc_documents": len(smoldoc),
        "smoldoc_sentence_pairs": min(
            len(doc_en),
            len(doc_kok)
        ),
        "smolsent_records": len(smolsent),
        "smolsent_sentence_pairs": min(
            len(sent_en),
            len(sent_kok)
        ),
        "combined_sentence_pairs": min(
            len(english_all),
            len(kokborok_all)
        ),
        "smoldoc_malformed_records": doc_malformed,
        "smolsent_malformed_records": sent_malformed
    }

    summary_output = (
        OUTPUT_DIR /
        "dataset_audit_summary.json"
    )

    with summary_output.open(
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            summary,
            f,
            indent=2,
            ensure_ascii=False
        )

    print(
        "\nSaved:",
        summary_output
    )

    print("\n" + "=" * 70)
    print("AUDIT COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()