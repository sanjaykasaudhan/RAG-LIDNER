import json
from pathlib import Path


DATA_DIR = Path("data/raw/kokborok_digitalisation")


def inspect_json(path):
    print("\n" + "=" * 70)
    print(f"FILE: {path.name}")
    print("=" * 70)

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    print("Python type:", type(data).__name__)

    if isinstance(data, list):
        print("Number of records:", len(data))

        if data:
            print("\nFirst record:")
            print(json.dumps(data[0], indent=2, ensure_ascii=False))

    elif isinstance(data, dict):
        print("Keys:")
        print(list(data.keys()))

        print("\nContent preview:")
        print(json.dumps(data, indent=2, ensure_ascii=False)[:3000])


def main():
    for path in DATA_DIR.glob("*.json"):
        inspect_json(path)


if __name__ == "__main__":
    main()