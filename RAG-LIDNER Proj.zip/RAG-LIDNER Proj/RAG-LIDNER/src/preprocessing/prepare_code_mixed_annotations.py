from pathlib import Path
import re
import pandas as pd


AUTHOR_FILE = Path(
    "data/raw/author_code_mixed/"
    "Kokborok Code-mixed dataset.txt"
)

PARALLEL_FILE = Path(
    "data/processed/clean_parallel_corpus.csv"
)

OUTPUT_DIR = Path(
    "data/annotations/batches"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ---------------------------------------------------------
# TOKENIZATION
# ---------------------------------------------------------

def tokenize(text):
    """
    Tokenization that preserves words and punctuation.
    """

    return re.findall(
        r"\w+(?:[-'][\w]+)*|[^\w\s]",
        text,
        flags=re.UNICODE
    )


# ---------------------------------------------------------
# LOAD AUTHOR DATASET
# ---------------------------------------------------------

def load_author_dataset():

    records = []

    with open(
        AUTHOR_FILE,
        "r",
        encoding="utf-8"
    ) as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            match = re.match(
                r"^(\d+)\.\s*(.*)$",
                line
            )

            if not match:
                continue

            sentence_id = int(
                match.group(1)
            )

            text = match.group(2).strip()

            records.append(
                {
                    "sentence_id": sentence_id,
                    "text": text
                }
            )

    return pd.DataFrame(records)


# ---------------------------------------------------------
# BUILD VOCABULARIES FROM REAL PARALLEL CORPUS
# ---------------------------------------------------------

def build_vocabularies():

    if not PARALLEL_FILE.exists():

        raise FileNotFoundError(
            f"Parallel corpus not found:\n"
            f"{PARALLEL_FILE}"
        )

    df = pd.read_csv(
        PARALLEL_FILE
    )

    english_vocab = set()
    kokborok_vocab = set()

    for text in df["english"].dropna():

        for token in tokenize(str(text)):

            token = token.lower()

            if token.isalpha():

                english_vocab.add(token)

    for text in df["kokborok"].dropna():

        for token in tokenize(str(text)):

            token = token.lower()

            if token.isalpha():

                kokborok_vocab.add(token)

    return english_vocab, kokborok_vocab


# ---------------------------------------------------------
# PRELIMINARY LANGUAGE IDENTIFICATION
# ---------------------------------------------------------

def candidate_language(token, english_vocab, kokborok_vocab):

    clean = token.lower()

    # punctuation / numbers
    if not clean.isalpha():

        return "OTHER"

    in_english = clean in english_vocab
    in_kokborok = clean in kokborok_vocab

    if in_english and not in_kokborok:

        return "EN"

    if in_kokborok and not in_english:

        return "KOK"

    if in_english and in_kokborok:

        return "AMBIG"

    return "UNK"


# ---------------------------------------------------------
# CREATE ANNOTATION TABLE
# ---------------------------------------------------------

def main():

    print("=" * 70)
    print("RAG-LIDNER CODE-MIXED ANNOTATION PREPARATION")
    print("=" * 70)

    print("\nLoading author dataset...")

    df = load_author_dataset()

    print(
        "Sentences:",
        len(df)
    )

    print("\nBuilding vocabularies...")

    english_vocab, kokborok_vocab = (
        build_vocabularies()
    )

    print(
        "English vocabulary:",
        len(english_vocab)
    )

    print(
        "Kokborok vocabulary:",
        len(kokborok_vocab)
    )

    rows = []

    for _, row in df.iterrows():

        sentence_id = int(
            row["sentence_id"]
        )

        text = row["text"]

        tokens = tokenize(text)

        for token_id, token in enumerate(tokens):

            candidate = candidate_language(
                token,
                english_vocab,
                kokborok_vocab
            )

            rows.append(
                {
                    "sentence_id": sentence_id,
                    "token_id": token_id,
                    "token": token,
                    "lid_candidate": candidate,
                    "lid_gold": "",
                    "ner_gold": "O"
                }
            )

    annotation_df = pd.DataFrame(rows)

    # -----------------------------------------------------
    # STATISTICS
    # -----------------------------------------------------

    print("\n" + "=" * 70)
    print("TOKEN STATISTICS")
    print("=" * 70)

    print(
        "Total tokens:",
        len(annotation_df)
    )

    print(
        "\nCandidate LID distribution:"
    )

    print(
        annotation_df[
            "lid_candidate"
        ]
        .value_counts()
        .to_string()
    )

    # -----------------------------------------------------
    # SAVE
    # -----------------------------------------------------

    output_csv = (
        OUTPUT_DIR /
        "code_mixed_token_annotations.csv"
    )

    annotation_df.to_csv(
        output_csv,
        index=False,
        encoding="utf-8"
    )

    # CoNLL-like format
    output_conll = (
        OUTPUT_DIR /
        "code_mixed_annotation.conll"
    )

    with open(
        output_conll,
        "w",
        encoding="utf-8"
    ) as f:

        current_sentence = None

        for _, row in annotation_df.iterrows():

            sentence_id = row["sentence_id"]

            if (
                current_sentence is not None
                and sentence_id != current_sentence
            ):

                f.write("\n")

            f.write(
                f"{row['token']}\t"
                f"{row['lid_candidate']}\t"
                f"{row['lid_gold']}\t"
                f"{row['ner_gold']}\n"
            )

            current_sentence = sentence_id

    print("\n" + "=" * 70)
    print("FILES CREATED")
    print("=" * 70)

    print(
        "CSV:",
        output_csv
    )

    print(
        "CoNLL:",
        output_conll
    )

    print("\nPreparation complete.")


if __name__ == "__main__":
    main()