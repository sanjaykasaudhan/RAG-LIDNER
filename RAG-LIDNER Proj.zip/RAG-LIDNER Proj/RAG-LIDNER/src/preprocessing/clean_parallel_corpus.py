import json
import re
from pathlib import Path

import pandas as pd


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[2]

RAW_DIR = (
    ROOT
    / "data"
    / "raw"
    / "kokborok_digitalisation"
)

OUTPUT_DIR = (
    ROOT
    / "data"
    / "processed"
)

METADATA_DIR = (
    ROOT
    / "data"
    / "metadata"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)

METADATA_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# CONFIGURATION
# ============================================================

MIN_TOKENS = 2
MAX_TOKENS = 100

FILES = [
    "smoldoc__en_trp.json",
    "smolsent__en_trp.json",
]


# ============================================================
# TEXT NORMALIZATION
# ============================================================

def normalize_text(text):
    """
    Conservative normalization.

    We do NOT:
    - lowercase
    - remove punctuation
    - transliterate
    - change Kokborok spelling

    This is important because linguistic information
    must be preserved.
    """

    if not isinstance(text, str):
        return ""

    text = text.strip()

    # Normalize whitespace
    text = re.sub(
        r"\s+",
        " ",
        text
    )

    return text


# ============================================================
# TOKENIZATION
# ============================================================

def tokenize(text):

    return re.findall(
        r"\b[\w'-]+\b",
        text,
        flags=re.UNICODE
    )


# ============================================================
# LOAD SMOLDOC
# ============================================================

def load_smoldoc():

    path = RAW_DIR / "smoldoc__en_trp.json"

    with path.open(
        "r",
        encoding="utf-8"
    ) as f:

        data = json.load(f)

    rows = []

    for record in data:

        srcs = record.get(
            "srcs",
            []
        )

        trgs = record.get(
            "trgs",
            []
        )

        if not isinstance(srcs, list):
            continue

        if not isinstance(trgs, list):
            continue

        if len(srcs) != len(trgs):
            continue

        for index, (
            src,
            trg
        ) in enumerate(
            zip(srcs, trgs)
        ):

            rows.append({
                "source_file":
                    "smoldoc__en_trp.json",

                "document_id":
                    record.get(
                        "id",
                        ""
                    ),

                "pair_id":
                    f"{record.get('id', '')}_{index}",

                "english":
                    src,

                "kokborok":
                    trg,

                "source_language":
                    record.get(
                        "sl",
                        "en"
                    ),

                "target_language":
                    record.get(
                        "tl",
                        "trp"
                    ),

                "is_src_orig":
                    record.get(
                        "is_src_orig"
                    ),

                "factuality":
                    record.get(
                        "factuality"
                    )
            })

    return rows


# ============================================================
# LOAD SMOLSENT
# ============================================================

def load_smolsent():

    path = RAW_DIR / "smolsent__en_trp.json"

    with path.open(
        "r",
        encoding="utf-8"
    ) as f:

        data = json.load(f)

    rows = []

    for record in data:

        src = record.get(
            "src"
        )

        trg = record.get(
            "trg"
        )

        if not isinstance(
            src,
            str
        ):
            continue

        if not isinstance(
            trg,
            str
        ):
            continue

        rows.append({
            "source_file":
                "smolsent__en_trp.json",

            "document_id":
                "",

            "pair_id":
                f"smolsent_{record.get('id', '')}",

            "english":
                src,

            "kokborok":
                trg,

            "source_language":
                record.get(
                    "sl",
                    "en"
                ),

            "target_language":
                record.get(
                    "tl",
                    "trp"
                ),

            "is_src_orig":
                record.get(
                    "is_src_orig"
                ),

            "factuality":
                None
        })

    return rows


# ============================================================
# VALIDATION
# ============================================================

def validate_rows(df):

    report = {}

    report["initial_rows"] = len(df)

    # --------------------------------------------------------
    # Missing values
    # --------------------------------------------------------

    report["missing_english"] = int(
        df["english"]
        .isna()
        .sum()
    )

    report["missing_kokborok"] = int(
        df["kokborok"]
        .isna()
        .sum()
    )

    # --------------------------------------------------------
    # Empty values
    # --------------------------------------------------------

    report["empty_english"] = int(
        (
            df["english"]
            .fillna("")
            .str.strip()
            == ""
        ).sum()
    )

    report["empty_kokborok"] = int(
        (
            df["kokborok"]
            .fillna("")
            .str.strip()
            == ""
        ).sum()
    )

    # --------------------------------------------------------
    # Exact bilingual duplicates
    # --------------------------------------------------------

    report["duplicate_pairs"] = int(
        df.duplicated(
            subset=[
                "english",
                "kokborok"
            ]
        ).sum()
    )

    return report


# ============================================================
# CLEANING
# ============================================================

def clean_dataframe(df):

    # --------------------------------------------------------
    # Normalize
    # --------------------------------------------------------

    df["english"] = (
        df["english"]
        .apply(normalize_text)
    )

    df["kokborok"] = (
        df["kokborok"]
        .apply(normalize_text)
    )

    # --------------------------------------------------------
    # Remove empty pairs
    # --------------------------------------------------------

    df = df[
        (df["english"] != "")
        &
        (df["kokborok"] != "")
    ].copy()

    # --------------------------------------------------------
    # Token lengths
    # --------------------------------------------------------

    df["english_tokens"] = (
        df["english"]
        .apply(tokenize)
        .apply(len)
    )

    df["kokborok_tokens"] = (
        df["kokborok"]
        .apply(tokenize)
        .apply(len)
    )

    # --------------------------------------------------------
    # Length filtering
    # --------------------------------------------------------

    df = df[
        (df["english_tokens"] >= MIN_TOKENS)
        &
        (df["kokborok_tokens"] >= MIN_TOKENS)
        &
        (df["english_tokens"] <= MAX_TOKENS)
        &
        (df["kokborok_tokens"] <= MAX_TOKENS)
    ].copy()

    # --------------------------------------------------------
    # Remove exact duplicate bilingual pairs
    # --------------------------------------------------------

    df = df.drop_duplicates(
        subset=[
            "english",
            "kokborok"
        ]
    ).reset_index(
        drop=True
    )

    # --------------------------------------------------------
    # Create stable corpus ID
    # --------------------------------------------------------

    df.insert(
        0,
        "corpus_id",
        [
            f"KOKEN_{i:06d}"
            for i in range(len(df))
        ]
    )

    return df


# ============================================================
# STATISTICS
# ============================================================

def calculate_statistics(
    before,
    after
):

    stats = {

        "records_before_cleaning":
            len(before),

        "records_after_cleaning":
            len(after),

        "records_removed":
            len(before) - len(after),

        "english_tokens":
            int(
                after["english_tokens"]
                .sum()
            ),

        "kokborok_tokens":
            int(
                after["kokborok_tokens"]
                .sum()
            ),

        "average_english_tokens":
            float(
                after["english_tokens"]
                .mean()
            ),

        "average_kokborok_tokens":
            float(
                after["kokborok_tokens"]
                .mean()
            ),

        "english_kokborok_length_ratio":
            float(
                after["english_tokens"].sum()
                /
                after["kokborok_tokens"].sum()
            )
    }

    return stats


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("RAG-LIDNER PARALLEL CORPUS CLEANING")
    print("=" * 70)

    # --------------------------------------------------------
    # Load
    # --------------------------------------------------------

    rows = []

    rows.extend(
        load_smoldoc()
    )

    rows.extend(
        load_smolsent()
    )

    df = pd.DataFrame(rows)

    print(
        "\nLoaded records:",
        len(df)
    )

    # --------------------------------------------------------
    # Validate
    # --------------------------------------------------------

    validation = validate_rows(
        df
    )

    print("\nVALIDATION")
    print("-" * 70)

    for key, value in validation.items():

        print(
            f"{key}: {value}"
        )

    # --------------------------------------------------------
    # Clean
    # --------------------------------------------------------

    clean_df = clean_dataframe(
        df
    )

    print("\nCLEANING")
    print("-" * 70)

    print(
        "Before:",
        len(df)
    )

    print(
        "After:",
        len(clean_df)
    )

    print(
        "Removed:",
        len(df) - len(clean_df)
    )

    # --------------------------------------------------------
    # Statistics
    # --------------------------------------------------------

    stats = calculate_statistics(
        df,
        clean_df
    )

    print("\nFINAL STATISTICS")
    print("-" * 70)

    for key, value in stats.items():

        print(
            f"{key}: {value}"
        )

    # --------------------------------------------------------
    # Save clean corpus
    # --------------------------------------------------------

    output_csv = (
        OUTPUT_DIR
        / "clean_parallel_corpus.csv"
    )

    clean_df.to_csv(
        output_csv,
        index=False,
        encoding="utf-8-sig"
    )

    print(
        "\nSaved clean corpus:",
        output_csv
    )

    # --------------------------------------------------------
    # Save JSONL
    # --------------------------------------------------------

    output_jsonl = (
        OUTPUT_DIR
        / "clean_parallel_corpus.jsonl"
    )

    clean_df.to_json(
        output_jsonl,
        orient="records",
        lines=True,
        force_ascii=False
    )

    print(
        "Saved JSONL:",
        output_jsonl
    )

    # --------------------------------------------------------
    # Save statistics
    # --------------------------------------------------------

    stats_df = pd.DataFrame(
        [stats]
    )

    statistics_output = (
        METADATA_DIR
        / "cleaning_statistics.csv"
    )

    stats_df.to_csv(
        statistics_output,
        index=False
    )

    print(
        "Saved statistics:",
        statistics_output
    )

    # --------------------------------------------------------
    # Save validation report
    # --------------------------------------------------------

    validation_df = pd.DataFrame(
        [validation]
    )

    validation_output = (
        METADATA_DIR
        / "validation_report.csv"
    )

    validation_df.to_csv(
        validation_output,
        index=False
    )

    print(
        "Saved validation report:",
        validation_output
    )

    print("\n" + "=" * 70)
    print("CLEANING COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()