from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[2]

INPUT = (
    ROOT
    / "data"
    / "metadata"
    / "kokborok_corpus_statistics.csv"
)

OUTPUT_DIR = (
    ROOT
    / "results"
    / "figures"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


def main():

    df = pd.read_csv(INPUT)

    # --------------------------------------------------------
    # Sentence count
    # --------------------------------------------------------

    plt.figure(figsize=(8, 5))

    plt.bar(
        df["language"],
        df["sentences"]
    )

    plt.xlabel("Language")
    plt.ylabel("Number of Sentences")
    plt.title("English–Kokborok Corpus Sentence Distribution")

    plt.tight_layout()

    output = (
        OUTPUT_DIR
        / "sentence_distribution.png"
    )

    plt.savefig(
        output,
        dpi=300
    )

    plt.close()

    print(
        "Saved:",
        output
    )


if __name__ == "__main__":
    main()