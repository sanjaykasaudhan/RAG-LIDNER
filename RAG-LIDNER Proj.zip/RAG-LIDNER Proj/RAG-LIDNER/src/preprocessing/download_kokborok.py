from huggingface_hub import hf_hub_download
from pathlib import Path


REPO_ID = "sdmy/kokborok"
REPO_TYPE = "dataset"

OUTPUT_DIR = Path("data/raw/kokborok_digitalisation")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

FILES = [
    "smoldoc__en_trp.json",
    "smolsent__en_trp.json",
    "correction.txt",
]


def main():
    for filename in FILES:
        print(f"Downloading: {filename}")

        downloaded = hf_hub_download(
            repo_id=REPO_ID,
            filename=filename,
            repo_type=REPO_TYPE,
            local_dir=str(OUTPUT_DIR),
        )

        print(f"Saved to: {downloaded}")

    print("\nDownload completed.")


if __name__ == "__main__":
    main()