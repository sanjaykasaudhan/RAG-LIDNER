import sys

import torch
import transformers
import datasets
import sentence_transformers
import faiss
import sklearn


print("=" * 60)
print("RAG-LIDNER ENVIRONMENT CHECK")
print("=" * 60)

print("Python:", sys.version)
print("PyTorch:", torch.__version__)
print("Transformers:", transformers.__version__)
print("Datasets:", datasets.__version__)
print("Sentence Transformers:", sentence_transformers.__version__)
print("FAISS:", faiss.__version__)
print("Scikit-learn:", sklearn.__version__)

print()

print("CUDA available:", torch.cuda.is_available())

if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
else:
    print("Running on CPU")

print("=" * 60)
print("Environment OK")
print("=" * 60)