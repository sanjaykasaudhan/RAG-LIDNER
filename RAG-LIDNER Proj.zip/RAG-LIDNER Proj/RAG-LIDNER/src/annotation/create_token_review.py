from pathlib import Path
import pandas as pd

INPUT_FILE = Path(
    "data/annotations/silver/code_mixed_silver_labels.csv"
)

OUTPUT_DIR = Path("data/annotations/review")
OUTPUT_FILE = OUTPUT_DIR / "token_level_review.csv"


LID_LABELS = {"EN", "KOK", "MIX", "OTHER"}

NER_LABELS = {
    "O",
    "B-PER", "I-PER",
    "B-ORG", "I-ORG",
    "B-LOC", "I-LOC",
    "B-DATE", "I-DATE",
    "B-MISC", "I-MISC",
}


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found: {INPUT_FILE}"
        )

    df = pd.read_csv(INPUT_FILE).fillna("")

    required_columns = {
        "sentence_id",
        "token_id",
        "token",
        "lid_candidate",
        "lid_pred",
        "ner_pred",
    }

    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(
            f"Missing required columns: {sorted(missing)}"
        )

    df["token_id"] = pd.to_numeric(
        df["token_id"], errors="raise"
    )

    df = df.sort_values(
        ["sentence_id", "token_id"]
    ).reset_index(drop=True)

    # Keep the original data and silver predictions.
    review = pd.DataFrame({
        "sentence_id": df["sentence_id"],
        "token_id": df["token_id"],
        "token": df["token"],
        "lid_candidate": df["lid_candidate"],
        "lid_pred_silver": df["lid_pred"],
        "ner_pred_silver": df["ner_pred"],
    })

    # These columns are for human-verified gold labels.
    review["lid_gold"] = ""
    review["ner_gold"] = ""
    review["review_status"] = "pending"
    review["review_notes"] = ""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    review.to_csv(
        OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    print(f"Tokens exported: {len(review)}")
    print(
        "Unique sentences:",
        review["sentence_id"].nunique()
    )
    print(f"Output file: {OUTPUT_FILE}")
    print("\nAllowed LID labels:", sorted(LID_LABELS))
    print("Allowed NER labels:", sorted(NER_LABELS))
    print(
        "\nGold columns are blank intentionally. "
        "Fill them only after reviewing each token."
    )


if __name__ == "__main__":
    main()