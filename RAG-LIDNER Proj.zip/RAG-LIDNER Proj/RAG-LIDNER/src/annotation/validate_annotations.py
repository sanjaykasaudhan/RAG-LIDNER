"""
RAG-LIDNER annotation validator
--------------------------------
Checks a pre-annotated token-level CSV without treating suggestions as gold labels.

Usage (from the RAG-LIDNER project root):
    python src/annotation/validate_annotations.py

Or provide a file path:
    python src/annotation/validate_annotations.py "data/annotations/review/gold_annotation_sample_preannotated.csv"

Outputs:
    data/annotations/review/annotation_validation_report.csv
    data/annotations/review/annotation_validation_summary.txt

Important:
- This script does NOT automatically approve suggestions.
- lid_gold and ner_gold remain unchanged.
- Review flagged rows and fill gold labels only after human verification.
"""

import csv
import sys
from collections import Counter
from pathlib import Path

VALID_LID = {"EN", "KOK", "MIX", "OTHER"}
VALID_NER = {
    "O",
    "B-PER", "I-PER",
    "B-ORG", "I-ORG",
    "B-LOC", "I-LOC",
    "B-DATE", "I-DATE",
    "B-MISC", "I-MISC",
}

REQUIRED_COLUMNS = {
    "sentence_id", "token_id", "token",
    "lid_suggestion", "ner_suggestion",
    "lid_gold", "ner_gold",
}

def clean(value):
    return (value or "").strip()

def main():
    if len(sys.argv) > 1:
        input_path = Path(sys.argv[1]).expanduser()
    else:
        input_path = Path("data/annotations/review/gold_annotation_sample_preannotated.csv")

    if not input_path.exists():
        print(f"ERROR: Cannot find input file:\n  {input_path.resolve()}")
        print("\nRun this script from your RAG-LIDNER project root, or pass the CSV path.")
        sys.exit(1)

    output_dir = input_path.parent
    report_path = output_dir / "annotation_validation_report.csv"
    summary_path = output_dir / "annotation_validation_summary.txt"

    with input_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        columns = reader.fieldnames or []
        rows = list(reader)

    missing_columns = sorted(REQUIRED_COLUMNS - set(columns))
    if missing_columns:
        print("ERROR: CSV is missing required columns:")
        for col in missing_columns:
            print(f"  - {col}")
        print(f"\nFound columns: {columns}")
        sys.exit(2)

    issues_counter = Counter()
    lid_suggestions = Counter()
    ner_suggestions = Counter()
    sentence_tokens = {}
    seen_positions = set()
    report_rows = []

    for row_num, row in enumerate(rows, start=2):
        issues = []
        sentence_id = clean(row.get("sentence_id"))
        token_id = clean(row.get("token_id"))
        token = clean(row.get("token"))
        lid_suggestion = clean(row.get("lid_suggestion"))
        ner_suggestion = clean(row.get("ner_suggestion"))
        lid_gold = clean(row.get("lid_gold"))
        ner_gold = clean(row.get("ner_gold"))

        if not sentence_id:
            issues.append("missing_sentence_id")
        if not token_id:
            issues.append("missing_token_id")
        if not token:
            issues.append("empty_token")

        pos = (sentence_id, token_id)
        if sentence_id and token_id:
            if pos in seen_positions:
                issues.append("duplicate_sentence_token_position")
                issues_counter["duplicate_sentence_token_position"] += 1
            seen_positions.add(pos)

        if lid_suggestion:
            lid_suggestions[lid_suggestion] += 1
            if lid_suggestion not in VALID_LID:
                issues.append("invalid_lid_suggestion")
        else:
            issues.append("missing_lid_suggestion")

        if ner_suggestion:
            ner_suggestions[ner_suggestion] += 1
            if ner_suggestion not in VALID_NER:
                issues.append("invalid_ner_suggestion")
        else:
            issues.append("missing_ner_suggestion")

        # Gold labels may be blank during review, but if filled they must be valid.
        if lid_gold and lid_gold not in VALID_LID:
            issues.append("invalid_lid_gold")
        if ner_gold and ner_gold not in VALID_NER:
            issues.append("invalid_ner_gold")

        if not lid_gold:
            issues.append("lid_gold_needs_human_review")
        if not ner_gold:
            issues.append("ner_gold_needs_human_review")

        # Flag BIO continuation labels that do not immediately follow a compatible B/I
        # entity of the same type within the same sentence.
        sentence_tokens.setdefault(sentence_id, []).append(
            (row_num, token_id, ner_suggestion, ner_gold)
        )

        for issue in set(issues):
            issues_counter[issue] += 1

        new_row = dict(row)
        new_row["validation_issues"] = ";".join(issues) if issues else "none"
        new_row["human_review_required"] = "YES" if (
            issues or not lid_gold or not ner_gold
        ) else "NO"
        report_rows.append(new_row)

    # Check BIO continuity in source row order, separately for each sentence.
    row_by_number = {i: r for i, r in enumerate(rows, start=2)}
    for sentence_id, items in sentence_tokens.items():
        items.sort(key=lambda x: int(x[1]) if x[1].isdigit() else 10**12)
        previous_suggestion = None
        previous_gold = None
        for row_num, token_id, ner_suggestion, ner_gold in items:
            for label, previous, field_name in (
                (ner_suggestion, previous_suggestion, "ner_suggestion"),
                (ner_gold, previous_gold, "ner_gold"),
            ):
                if label.startswith("I-"):
                    entity_type = label[2:]
                    if previous not in {f"B-{entity_type}", f"I-{entity_type}"}:
                        issue = f"BIO_sequence_check_{field_name}"
                        report_row = report_rows[row_num - 2]
                        current = report_row.get("validation_issues", "")
                        report_row["validation_issues"] = (
                            issue if current in ("", "none") else current + ";" + issue
                        )
                        report_row["human_review_required"] = "YES"
                        issues_counter[issue] += 1
            previous_suggestion = ner_suggestion or None
            previous_gold = ner_gold or None

    with report_path.open("w", encoding="utf-8-sig", newline="") as f:
        fieldnames = list(columns)
        if "validation_issues" not in fieldnames:
            fieldnames += ["validation_issues", "human_review_required"]
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(report_rows)

    sentence_count = len({clean(r.get("sentence_id")) for r in rows if clean(r.get("sentence_id"))})
    gold_lid_filled = sum(bool(clean(r.get("lid_gold"))) for r in rows)
    gold_ner_filled = sum(bool(clean(r.get("ner_gold"))) for r in rows)
    review_count = sum(r.get("human_review_required") == "YES" for r in report_rows)

    summary_lines = [
        "RAG-LIDNER ANNOTATION VALIDATION SUMMARY",
        "=" * 42,
        f"Input file: {input_path.resolve()}",
        f"Rows/tokens: {len(rows)}",
        f"Unique sentence IDs: {sentence_count}",
        f"Gold LID labels filled: {gold_lid_filled}/{len(rows)}",
        f"Gold NER labels filled: {gold_ner_filled}/{len(rows)}",
        f"Rows requiring review: {review_count}/{len(rows)}",
        "",
        "LID suggestion counts:",
        *(f"  {label}: {count}" for label, count in sorted(lid_suggestions.items())),
        "",
        "NER suggestion counts:",
        *(f"  {label}: {count}" for label, count in sorted(ner_suggestions.items())),
        "",
        "Validation issue counts (a row can have more than one issue):",
        *(f"  {issue}: {count}" for issue, count in sorted(issues_counter.items())),
        "",
        "IMPORTANT: Suggestions are not verified ground truth.",
        "Review each token in context. Fill lid_gold and ner_gold only after verification.",
        f"Detailed report: {report_path.resolve()}",
    ]
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    print("\n".join(summary_lines))
    print("\nDone. Your input file was not modified.")

if __name__ == "__main__":
    main()
