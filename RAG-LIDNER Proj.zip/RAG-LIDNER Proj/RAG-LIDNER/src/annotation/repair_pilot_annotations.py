from pathlib import Path
import pandas as pd
import re

source = Path("data/annotations/review/gold_annotation_sample_preannotated.csv")
output = Path("data/annotations/review/gold_annotation_pilot_repair.csv")

df = pd.read_csv(source, dtype=str, keep_default_na=False)

valid_lid = {"EN", "KOK", "MIX", "OTHER"}
valid_ner = {
    "O", "B-PER", "I-PER", "B-ORG", "I-ORG",
    "B-LOC", "I-LOC", "B-DATE", "I-DATE",
    "B-MISC", "I-MISC"
}

def extract_notes(row):
    notes = row["review_notes"].strip()
    parts = [p.strip() for p in notes.split(";")]

    lid = ""
    ner = ""

    if parts:
        possible_lid = parts[0].upper()
        if possible_lid in valid_lid:
            lid = possible_lid

    if len(parts) > 1:
        possible_ner = parts[1].upper()
        if possible_ner in valid_ner:
            ner = possible_ner

    # Handle Ata's shifted columns
    if row["review_status"].upper() in valid_lid:
        lid = row["review_status"].upper()

    return pd.Series({
        "proposed_lid": lid,
        "proposed_ner": ner
    })

proposals = df.apply(extract_notes, axis=1)

df["proposed_lid"] = proposals["proposed_lid"]
df["proposed_ner"] = proposals["proposed_ner"]

# Never automatically promote notes to verified gold.
# Keep the original gold labels and review notes unchanged.
df["repair_review_status"] = "needs_human_verification"

# Identify contradictory or uncertain rows.
def flag_row(row):
    notes = row["review_notes"].lower()
    flags = []

    if not row["proposed_lid"] or not row["proposed_ner"]:
        flags.append("missing_or_invalid_proposal")

    if "confirm" in notes or "uncertain" in notes:
        flags.append("explicit_uncertainty")

    if row["token"].lower() == "nwng" and row["proposed_lid"] == "EN":
        flags.append("check_nwng_language")

    if row["token"].lower() == "tini" and row["proposed_ner"] != "O":
        flags.append("check_tini_entity")

    if row["token"].lower() == "office" and row["proposed_ner"] != "O":
        flags.append("check_generic_office_entity")

    return "; ".join(flags)

df["repair_flags"] = df.apply(flag_row, axis=1)

output.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(output, index=False, encoding="utf-8-sig")

print("Repair review file created:", output)
print("Rows:", len(df))
print("Proposed LID labels:", (df["proposed_lid"] != "").sum())
print("Proposed NER labels:", (df["proposed_ner"] != "").sum())
print("Rows flagged:", (df["repair_flags"] != "").sum())

print("\nPreview:")
print(df[
    [
        "sentence_id", "token_id", "token",
        "proposed_lid", "proposed_ner",
        "repair_review_status", "repair_flags"
    ]
].head(15).to_string(index=False))