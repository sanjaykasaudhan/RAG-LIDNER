from pathlib import Path
import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[2]

INPUT_FILE = (
    BASE_DIR
    / "data"
    / "annotations"
    / "batches"
    / "code_mixed_token_annotations.csv"
)

OUTPUT_DIR = (
    BASE_DIR
    / "data"
    / "annotations"
    / "annotated"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)

OUTPUT_FILE = (
    OUTPUT_DIR
    / "batch_001_annotated.csv"
)

HOST = "127.0.0.1"
PORT = 5000

BATCH_START = 1
BATCH_END = 100


# ============================================================
# LABELS
# ============================================================

LID_LABELS = [
    "EN",
    "KOK",
    "MIX",
    "OTHER"
]

NER_LABELS = [
    "O",
    "B-PER",
    "I-PER",
    "B-ORG",
    "I-ORG",
    "B-LOC",
    "I-LOC",
    "B-DATE",
    "I-DATE",
    "B-MISC",
    "I-MISC"
]


# ============================================================
# LOAD DATA
# ============================================================

print("=" * 70)
print("RAG-LIDNER LOCAL ANNOTATION SERVER")
print("=" * 70)

print(f"Project: {BASE_DIR}")
print(f"Input:   {INPUT_FILE}")
print(f"Output:  {OUTPUT_FILE}")

if not INPUT_FILE.exists():
    raise FileNotFoundError(
        f"Dataset not found:\n{INPUT_FILE}"
    )


df = pd.read_csv(
    INPUT_FILE,
    keep_default_na=False,
    dtype=str
)

required = [
    "sentence_id",
    "token_id",
    "token",
    "lid_candidate",
    "lid_gold",
    "ner_gold"
]

missing = [
    c for c in required
    if c not in df.columns
]

if missing:
    raise ValueError(
        f"Missing columns: {missing}"
    )


df["sentence_id"] = pd.to_numeric(
    df["sentence_id"]
)

df["token_id"] = pd.to_numeric(
    df["token_id"]
)

df["lid_gold"] = df["lid_gold"].fillna("")

df["ner_gold"] = df["ner_gold"].fillna("O")


# ============================================================
# LOAD FIRST BATCH
# ============================================================

batch_df = df[
    (df["sentence_id"] >= BATCH_START)
    &
    (df["sentence_id"] <= BATCH_END)
].copy()


sentence_ids = sorted(
    batch_df["sentence_id"].unique()
)


print(f"Total tokens: {len(df)}")
print(f"Batch sentences: {len(sentence_ids)}")
print(f"Batch tokens: {len(batch_df)}")


# ============================================================
# LOAD EXISTING ANNOTATIONS
# ============================================================

if OUTPUT_FILE.exists():

    print("Existing annotation file found.")
    print("Resuming previous annotation.")

    existing = pd.read_csv(
        OUTPUT_FILE,
        keep_default_na=False,
        dtype=str
    )

    existing["sentence_id"] = pd.to_numeric(
        existing["sentence_id"]
    )

    existing["token_id"] = pd.to_numeric(
        existing["token_id"]
    )

    for _, row in existing.iterrows():

        mask = (
            (batch_df["sentence_id"] == row["sentence_id"])
            &
            (batch_df["token_id"] == row["token_id"])
        )

        if mask.any():

            batch_df.loc[
                mask,
                "lid_gold"
            ] = row.get("lid_gold", "")

            batch_df.loc[
                mask,
                "ner_gold"
            ] = row.get("ner_gold", "O")


# ============================================================
# GLOBAL LOCK
# ============================================================

data_lock = threading.Lock()


# ============================================================
# GET SENTENCE
# ============================================================

def get_sentence(sentence_id):

    group = batch_df[
        batch_df["sentence_id"] == sentence_id
    ].sort_values("token_id")

    tokens = []

    for _, row in group.iterrows():

        tokens.append({
            "token_id": int(row["token_id"]),
            "token": str(row["token"]),
            "lid_candidate": str(row["lid_candidate"]),
            "lid_gold": str(row["lid_gold"]),
            "ner_gold": str(row["ner_gold"])
        })

    text = " ".join(
        str(x["token"])
        for x in tokens
    )

    return {
        "sentence_id": int(sentence_id),
        "text": text,
        "tokens": tokens
    }


# ============================================================
# SAVE
# ============================================================

def save_annotations():

    with data_lock:

        batch_df.to_csv(
            OUTPUT_FILE,
            index=False,
            encoding="utf-8"
        )

    print(
        f"Saved: {OUTPUT_FILE}"
    )


# ============================================================
# HTML
# ============================================================

HTML = r"""
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>RAG-LIDNER Annotation</title>

<style>

body {
    font-family: Arial, sans-serif;
    margin: 0;
    background: #f4f6f8;
}

.header {
    background: #202124;
    color: white;
    padding: 18px 30px;
}

.header h1 {
    margin: 0;
    font-size: 22px;
}

.container {
    max-width: 1400px;
    margin: 20px auto;
    padding: 0 20px;
}

.card {
    background: white;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 18px;
    box-shadow: 0 2px 8px rgba(0,0,0,.08);
}

.sentence {
    font-size: 20px;
    line-height: 1.7;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 6px;
}

.progress {
    font-size: 15px;
    color: #555;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #f1f3f4;
    padding: 10px;
    text-align: left;
}

td {
    padding: 8px;
    border-bottom: 1px solid #ddd;
}

tr.selected {
    background: #e8f0fe;
}

button,
select,
input {
    font-size: 15px;
    padding: 8px;
}

button {
    cursor: pointer;
    border: none;
    border-radius: 5px;
    background: #1a73e8;
    color: white;
    padding: 10px 18px;
}

button:hover {
    opacity: .9;
}

.secondary {
    background: #5f6368;
}

.success {
    background: #188038;
}

.controls {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.note {
    width: 500px;
}

.candidate {
    font-weight: bold;
}

.legend {
    line-height: 1.8;
}

</style>

</head>


<body>


<div class="header">

<h1>
RAG-LIDNER — Joint Language Identification + NER
</h1>

</div>


<div class="container">


<div class="card">

<div id="progress" class="progress">
Loading...
</div>

<h2>Current Sentence</h2>

<div id="sentence" class="sentence">
Loading...
</div>

</div>


<div class="card">

<h2>Token Annotations</h2>

<table>

<thead>

<tr>

<th>Token ID</th>
<th>Token</th>
<th>LID Candidate</th>
<th>LID Gold</th>
<th>NER Gold</th>

</tr>

</thead>

<tbody id="tokens">

</tbody>

</table>

</div>


<div class="card">

<h2>Selected Token</h2>

<div class="controls">

<span>
<b>Token:</b>
<span id="selectedToken">None</span>
</span>

<span>
<b>Candidate:</b>
<span id="selectedCandidate">None</span>
</span>

<label>
LID Gold:
<select id="lid">
<option value="">-- select --</option>
<option>EN</option>
<option>KOK</option>
<option>MIX</option>
<option>OTHER</option>
</select>
</label>

<label>
NER Gold:
<select id="ner">

<option>O</option>

<option>B-PER</option>
<option>I-PER</option>

<option>B-ORG</option>
<option>I-ORG</option>

<option>B-LOC</option>
<option>I-LOC</option>

<option>B-DATE</option>
<option>I-DATE</option>

<option>B-MISC</option>
<option>I-MISC</option>

</select>
</label>

<button onclick="applyAnnotation()">
Apply Token
</button>

</div>


<br>


<div class="controls">

<label>
Annotator:
<input id="annotator"
       value="Annotator_1">
</label>

<label>
Notes:
<input id="notes"
       class="note">
</label>

</div>

</div>


<div class="card">

<div class="controls">

<button
    class="secondary"
    onclick="previousSentence()">
← Previous
</button>

<button
    onclick="nextSentence()">
Next →
</button>

<button
    class="success"
    onclick="saveAnnotations()">
Save
</button>

</div>

</div>


<div class="card legend">

<h3>Annotation Reminder</h3>

<b>LID</b>

<br>

EN = English lexical item

<br>

KOK = Kokborok lexical item

<br>

MIX = genuinely mixed single token

<br>

OTHER = punctuation/symbol/non-linguistic item

<br><br>

<b>NER</b>

<br>

O = not an entity

<br>

B-* = beginning of entity

<br>

I-* = continuation of entity

</div>


</div>


<script>

let sentences = [];
let currentIndex = 0;
let selectedTokenId = null;


async function loadData() {

    const response =
        await fetch("/api/data");

    const data =
        await response.json();

    sentences =
        data.sentences;

    currentIndex = 0;

    renderSentence();
}


function renderSentence() {

    const sentence =
        sentences[currentIndex];

    document.getElementById("progress")
        .innerText =
        "Sentence " +
        (currentIndex + 1) +
        " / " +
        sentences.length +
        " | Dataset ID: " +
        sentence.sentence_id;

    document.getElementById("sentence")
        .innerText =
        sentence.text;

    const tbody =
        document.getElementById("tokens");

    tbody.innerHTML = "";

    selectedTokenId = null;

    sentence.tokens.forEach(
        token => {

            const tr =
                document.createElement("tr");

            tr.dataset.tokenId =
                token.token_id;

            tr.onclick =
                () => selectToken(token, tr);

            tr.innerHTML = `

<td>${token.token_id}</td>

<td><b>${escapeHtml(token.token)}</b></td>

<td class="candidate">
${escapeHtml(token.lid_candidate)}
</td>

<td>
${escapeHtml(token.lid_gold || "—")}
</td>

<td>
${escapeHtml(token.ner_gold || "O")}
</td>

`;

            tbody.appendChild(tr);

        }
    );
}


function selectToken(token, row) {

    document
        .querySelectorAll("tbody tr")
        .forEach(
            r => r.classList.remove("selected")
        );

    row.classList.add("selected");

    selectedTokenId =
        token.token_id;

    document.getElementById(
        "selectedToken"
    ).innerText =
        token.token;

    document.getElementById(
        "selectedCandidate"
    ).innerText =
        token.lid_candidate;

    document.getElementById(
        "lid"
    ).value =
        token.lid_gold || "";

    document.getElementById(
        "ner"
    ).value =
        token.ner_gold || "O";

}


async function applyAnnotation() {

    if (selectedTokenId === null) {

        alert(
            "Please select a token first."
        );

        return;
    }

    const sentence =
        sentences[currentIndex];

    const lid =
        document.getElementById("lid").value;

    const ner =
        document.getElementById("ner").value;

    if (!lid) {

        alert(
            "Please select a LID Gold label."
        );

        return;
    }

    const annotator =
        document.getElementById("annotator").value;

    const notes =
        document.getElementById("notes").value;


    await fetch(
        "/api/annotate",
        {
            method: "POST",

            headers: {
                "Content-Type":
                "application/json"
            },

            body: JSON.stringify({

                sentence_id:
                sentence.sentence_id,

                token_id:
                selectedTokenId,

                lid_gold:
                lid,

                ner_gold:
                ner,

                annotator:
                annotator,

                notes:
                notes

            })

        }
    );


    const token =
        sentence.tokens.find(
            t =>
            t.token_id === selectedTokenId
        );

    token.lid_gold = lid;

    token.ner_gold = ner;

    renderSentence();


    alert(
        "Token annotation applied."
    );

}


async function saveAnnotations() {

    const response =
        await fetch(
            "/api/save",
            {
                method: "POST"
            }
        );

    const result =
        await response.json();

    alert(
        result.message
    );

}


async function nextSentence() {

    await saveSilent();

    if (
        currentIndex <
        sentences.length - 1
    ) {

        currentIndex++;

        renderSentence();

    }

}


async function previousSentence() {

    await saveSilent();

    if (currentIndex > 0) {

        currentIndex--;

        renderSentence();

    }

}


async function saveSilent() {

    await fetch(
        "/api/save",
        {
            method: "POST"
        }
    );

}


function escapeHtml(text) {

    return String(text)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


loadData();

</script>


</body>

</html>
"""


# ============================================================
# HTTP SERVER
# ============================================================

class Handler(BaseHTTPRequestHandler):

    def send_json(self, data, status=200):

        payload = json.dumps(
            data,
            ensure_ascii=False
        ).encode("utf-8")

        self.send_response(status)

        self.send_header(
            "Content-Type",
            "application/json; charset=utf-8"
        )

        self.send_header(
            "Content-Length",
            str(len(payload))
        )

        self.end_headers()

        self.wfile.write(payload)


    def do_GET(self):

        parsed = urlparse(self.path)

        if parsed.path == "/":

            payload = HTML.encode(
                "utf-8"
            )

            self.send_response(200)

            self.send_header(
                "Content-Type",
                "text/html; charset=utf-8"
            )

            self.send_header(
                "Content-Length",
                str(len(payload))
            )

            self.end_headers()

            self.wfile.write(
                payload
            )

            return


        if parsed.path == "/api/data":

            sentences = [
                get_sentence(sid)
                for sid in sentence_ids
            ]

            self.send_json({
                "sentences":
                sentences
            })

            return


        self.send_error(
            404,
            "Not Found"
        )


    def do_POST(self):

        parsed = urlparse(self.path)

        length = int(
            self.headers.get(
                "Content-Length",
                0
            )
        )

        try:

            data = json.loads(
                body.decode("utf-8")
            )

        except Exception:

            self.send_json(
                {
                    "error": "Invalid JSON"
                },
                400
            )

            return


        if parsed.path == "/api/annotate":

            sentence_id = int(data["sentence_id"])

            token_id = int(data["token_id"])


            with data_lock:

                mask = (
                    (batch_df["sentence_id"]
                     == sentence_id)
                    &
                    (batch_df["token_id"]
                     == token_id)
                )

                if not mask.any():

                    self.send_json(
                        {
                            "error":
                            "Token not found"
                        },
                        404
                    )

                    return


                batch_df.loc[
                    mask,
                    "lid_gold"
                ] = data.get(
                    "lid_gold",
                    ""
                )


                batch_df.loc[
                    mask,
                    "ner_gold"
                ] = data.get(
                    "ner_gold",
                    "O"
                )


                if "annotator" not in batch_df.columns:

                    batch_df["annotator"] = ""

                if "notes" not in batch_df.columns:

                    batch_df["notes"] = ""


                batch_df.loc[
                    mask,
                    "annotator"
                ] = data.get(
                    "annotator",
                    ""
                )


                batch_df.loc[
                    mask,
                    "notes"
                ] = data.get(
                    "notes",
                    ""
                )


            save_annotations()


            self.send_json(
                {
                    "status":
                    "ok"
                }
            )

            return


        if parsed.path == "/api/save":

            save_annotations()

            self.send_json(
                {
                    "status":
                    "ok",

                    "message":
                    "Annotations saved successfully."
                }
            )

            return


        self.send_error(
            404,
            "Not Found"
        )


    def log_message(
        self,
        format,
        *args
    ):

        return


# ============================================================
# START SERVER
# ============================================================

server = ThreadingHTTPServer(
    (HOST, PORT),
    Handler
)

url = (
    f"http://{HOST}:{PORT}"
)

print()
print("=" * 70)
print("ANNOTATION SERVER RUNNING")
print("=" * 70)
print()
print(f"Open this in Chrome:")
print()
print(f"    {url}")
print()
print("Batch: 001")
print("Sentences: 1-100")
print()
print("Keep this PowerShell window running.")
print("Press CTRL+C here when you want to stop the server.")
print("=" * 70)


# Open browser automatically

threading.Timer(
    1.0,
    lambda:
    webbrowser.open(url)
).start()


try:

    server.serve_forever()

except KeyboardInterrupt:

    print()
    print("Stopping server...")

finally:

    save_annotations()

    server.server_close()

    print(
        "Annotation server stopped."
    )

