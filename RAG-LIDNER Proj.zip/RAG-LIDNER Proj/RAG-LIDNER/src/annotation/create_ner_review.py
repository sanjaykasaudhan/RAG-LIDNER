from pathlib import Path
import pandas as pd

INPUT_FILE = Path(
    "data/annotations/silver/code_mixed_silver_labels.csv"
)

OUTPUT_DIR = Path("data/annotations/review")
OUTPUT_FILE = OUTPUT_DIR / "ner_entity_review.csv"


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"File not found: {INPUT_FILE}")

    df = pd.read_csv(INPUT_FILE).fillna("")
    df["token_id"] = pd.to_numeric(df["token_id"])

    # Reconstruct each sentence from its original tokens.
    sentence_text = (
        df.sort_values(["sentence_id", "token_id"])
        .groupby("sentence_id")["token"]
        .apply(lambda tokens: " ".join(tokens))
        .to_dict()
    )

    entities = df[df["ner_pred"].ne("O")].copy()

    entities["sentence_text"] = entities["sentence_id"].map(
        sentence_text
    )

    # Keep review columns separate from the predicted labels.
    review = entities[
        [
            "sentence_id",
            "sentence_text",
            "token_id",
            "token",
            "lid_pred",
            "ner_pred",
            "ner_model_score",
        ]
    ].copy()

    review["ner_verified"] = ""
    review["review_notes"] = ""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    review.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    print(f"Predicted entity tokens: {len(review)}")
    print(f"Review file: {OUTPUT_FILE}")
    print("\nEntity tag counts:")
    print(review["ner_pred"].value_counts().to_string())
    print("\nVerify each prediction against its complete sentence.")
    print("Use ner_verified for reviewed labels; do not overwrite predictions.")


if __name__ == "__main__":
    main()