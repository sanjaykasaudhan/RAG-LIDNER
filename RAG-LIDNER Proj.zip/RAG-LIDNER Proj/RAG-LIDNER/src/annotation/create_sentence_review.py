
from pathlib import Path
import pandas as pd

INPUT_FILE = Path(
    "data/annotations/silver/code_mixed_silver_labels.csv"
)
OUTPUT_DIR = Path("data/annotations/review")
OUTPUT_FILE = OUTPUT_DIR / "sentence_level_review.csv"


def main():
    df = pd.read_csv(INPUT_FILE).fillna("")
    df["token_id"] = pd.to_numeric(df["token_id"])

    records = []

    for sentence_id, group in df.groupby("sentence_id", sort=False):
        group = group.sort_values("token_id")

        tokens = group["token"].astype(str).tolist()
        text = " ".join(tokens)

        predicted_entities = group.loc[
            group["ner_pred"].ne("O"),
            ["token", "ner_pred", "ner_model_score"]
        ]

        entity_summary = "; ".join(
            f"{row.token} [{row.ner_pred}; score={row.ner_model_score}]"
            for row in predicted_entities.itertuples(index=False)
        )

        records.append({
            "sentence_id": sentence_id,
            "sentence_text": text,
            "predicted_entities": entity_summary,
            "sentence_verified": "",
            "review_notes": "",
        })

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(records).to_csv(
        OUTPUT_FILE, index=False, encoding="utf-8-sig"
    )

    print(f"Sentences exported: {len(records)}")
    print(f"Review file: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
