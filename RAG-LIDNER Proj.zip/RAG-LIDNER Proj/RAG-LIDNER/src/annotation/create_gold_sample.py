from pathlib import Path
import pandas as pd

INPUT_FILE = Path(
    "data/annotations/review/token_level_review.csv"
)

OUTPUT_DIR = Path("data/annotations/review")
OUTPUT_FILE = OUTPUT_DIR / "gold_annotation_sample.csv"

SAMPLE_FRACTION = 0.10
RANDOM_SEED = 42


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found: {INPUT_FILE}"
        )

    df = pd.read_csv(INPUT_FILE).fillna("")

    required = {
        "sentence_id",
        "token_id",
        "token",
        "lid_pred_silver",
        "ner_pred_silver",
        "lid_gold",
        "ner_gold",
    }

    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            f"Missing columns: {sorted(missing)}"
        )

    # Summarize each sentence to support stratified sampling.
    sentence_stats = (
        df.groupby("sentence_id", sort=False)
        .agg(
            has_predicted_entity=(
                "ner_pred_silver",
                lambda s: s.astype(str).ne("").where(
                    s.astype(str).ne(""), False
                ).where(
                    s.astype(str).ne("O"), True
                ).any()
            ),
            has_lid_prediction=(
                "lid_pred_silver",
                lambda s: s.astype(str).str.strip().ne("").any()
            ),
        )
        .reset_index()
    )

    # Sample within each of the four groups.
    selected_parts = []

    for _, group in sentence_stats.groupby(
        ["has_predicted_entity", "has_lid_prediction"],
        dropna=False,
        sort=True,
    ):
        n = max(1, round(len(group) * SAMPLE_FRACTION))
        n = min(n, len(group))

        selected_parts.append(
            group.sample(n=n, random_state=RANDOM_SEED)
        )

    selected_ids = set(
        pd.concat(selected_parts)["sentence_id"]
    )

    sample = df[df["sentence_id"].isin(selected_ids)].copy()
    sample = sample.sort_values(
        ["sentence_id", "token_id"]
    )

    # Gold labels must remain blank until human verification.
    sample["lid_gold"] = ""
    sample["ner_gold"] = ""
    sample["review_status"] = "pending"
    sample["review_notes"] = ""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    sample.to_csv(
        OUTPUT_FILE,
        index=False,
        encoding="utf-8-sig",
    )

    print("Gold annotation candidate sample created.")
    print(f"Sentences selected: {sample['sentence_id'].nunique()}")
    print(f"Token rows selected: {len(sample)}")
    print(f"Output: {OUTPUT_FILE}")
    print("\nGold columns are blank for manual annotation.")


if __name__ == "__main__":
    main()