
from pathlib import Path
import re
import pandas as pd

from src.preprocessing.prepare_code_mixed_annotations import (
    build_vocabularies,
)

INPUT_FILE = Path(
    "data/annotations/batches/code_mixed_token_annotations.csv"
)

OUTPUT_DIR = Path("data/annotations/silver")
OUTPUT_FILE = OUTPUT_DIR / "code_mixed_silver_labels.csv"


def predict_lid(token, english_vocab, kokborok_vocab):
    """Conservative vocabulary-based LID prediction."""

    clean = token.lower()

    if not clean.isalpha():
        return "OTHER", "high", False

    in_en = clean in english_vocab
    in_kok = clean in kokborok_vocab

    if in_en and not in_kok:
        return "EN", "medium", False

    if in_kok and not in_en:
        return "KOK", "medium", False

    # Do not guess when vocabularies overlap or lack the token.
    if in_en and in_kok:
        return "", "low", True

    return "", "low", True


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input annotation file not found: {INPUT_FILE}"
        )

    print("Loading token annotation data...")
    df = pd.read_csv(INPUT_FILE).fillna("")

    required = {"sentence_id", "token_id", "token"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    print("Building vocabularies from the existing parallel corpus...")
    english_vocab, kokborok_vocab = build_vocabularies()

    predictions = [
        predict_lid(str(token), english_vocab, kokborok_vocab)
        for token in df["token"]
    ]

    df["lid_pred"] = [item[0] for item in predictions]
    df["lid_confidence"] = [item[1] for item in predictions]
    df["lid_review_required"] = [item[2] for item in predictions]

    # Preserve the existing labels. Do not pretend the predictions
    # have been human-verified.
    if "lid_gold" not in df.columns:
        df["lid_gold"] = ""

    if "ner_gold" not in df.columns:
        df["ner_gold"] = ""

    df["ner_pred"] = ""
    df["ner_review_required"] = True
    df["label_source"] = "vocabulary_weak_supervision"

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    print("\nSilver-label generation complete.")
    print(f"Input tokens: {len(df)}")
    print(f"Output: {OUTPUT_FILE}")

    print("\nLID prediction counts:")
    print(df["lid_pred"].replace("", "REVIEW").value_counts())

    print("\nLID tokens requiring review:")
    print(int(df["lid_review_required"].sum()))

    print("\nNER predictions are intentionally left blank.")
    print("Use a separate NER model and reviewed test set before")
    print("claiming that the NER task is annotated or evaluated.")


if __name__ == "__main__":
    main()