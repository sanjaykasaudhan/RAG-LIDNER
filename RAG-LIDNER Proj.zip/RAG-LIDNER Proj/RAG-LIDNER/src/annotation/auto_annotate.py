from pathlib import Path
import re

import pandas as pd
from transformers import pipeline

from src.preprocessing.prepare_code_mixed_annotations import (
    build_vocabularies,
)

INPUT_FILE = Path(
    "data/annotations/batches/code_mixed_token_annotations.csv"
)
OUTPUT_DIR = Path("data/annotations/silver")
OUTPUT_FILE = OUTPUT_DIR / "code_mixed_silver_labels.csv"

NER_MODEL = "dslim/bert-base-NER"
NER_BATCH_SIZE = 8
NER_MIN_SCORE = 0.70


def predict_lid(token, english_vocab, kokborok_vocab):
    clean = token.lower()

    if not clean.isalpha():
        return "OTHER", "high", False

    in_en = clean in english_vocab
    in_kok = clean in kokborok_vocab

    if in_en and not in_kok:
        return "EN", "medium", False

    if in_kok and not in_en:
        return "KOK", "medium", False

    return "", "low", True


def token_offsets(tokens):
    """Create offsets for tokens joined with single spaces."""
    offsets = []
    parts = []
    cursor = 0

    for token in tokens:
        if parts:
            cursor += 1

        start = cursor
        end = start + len(token)
        offsets.append((start, end))
        parts.append(token)
        cursor = end

    return " ".join(parts), offsets


def assign_ner_labels(tokens, entities):
    """
    Map model character spans onto original tokens.
    Return BIO labels and token-level model scores.
    """
    sentence, offsets = token_offsets(tokens)
    labels = ["O"] * len(tokens)
    scores = [0.0] * len(tokens)

    for entity in entities:
        label = entity.get("entity_group", "MISC")
        score = float(entity.get("score", 0.0))
        start = int(entity.get("start", 0))
        end = int(entity.get("end", 0))

        if score < NER_MIN_SCORE:
            continue

        if label not in {"PER", "ORG", "LOC", "MISC"}:
            label = "MISC"

        overlapping = [
            i for i, (tok_start, tok_end) in enumerate(offsets)
            if tok_start < end and tok_end > start
        ]

        for i in overlapping:
            # Keep the highest-scoring overlapping prediction.
            if score > scores[i]:
                labels[i] = label
                scores[i] = score

    # Convert token-level entity types into BIO tags.
    bio = []
    previous_label = None

    for label in labels:
        if label == "O":
            bio.append("O")
            previous_label = None
        elif label == previous_label:
            bio.append(f"I-{label}")
            previous_label = label
        else:
            bio.append(f"B-{label}")
            previous_label = label

    return bio, scores


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Input not found: {INPUT_FILE}")

    print("Loading token annotation data...")
    df = pd.read_csv(INPUT_FILE).fillna("")

    required = {"sentence_id", "token_id", "token"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    df["token"] = df["token"].astype(str)

    print("Building vocabularies from the parallel corpus...")
    english_vocab, kokborok_vocab = build_vocabularies()

    lid_results = [
        predict_lid(token, english_vocab, kokborok_vocab)
        for token in df["token"]
    ]

    df["lid_pred"] = [x[0] for x in lid_results]
    df["lid_confidence"] = [x[1] for x in lid_results]
    df["lid_review_required"] = [x[2] for x in lid_results]

    print("Loading pretrained English NER model...")
    ner = pipeline(
        "token-classification",
        model=NER_MODEL,
        aggregation_strategy="simple",
    )

    # Process one sentence at a time while preserving original tokens.
    groups = list(df.groupby("sentence_id", sort=False))
    texts = []

    for _, group in groups:
        group = group.sort_values("token_id")
        text, _ = token_offsets(group["token"].tolist())
        texts.append(text)

    print(f"Running NER on {len(texts)} sentences...")
    all_entities = []

    for start in range(0, len(texts), NER_BATCH_SIZE):
        batch = texts[start:start + NER_BATCH_SIZE]
        batch_results = ner(batch, batch_size=NER_BATCH_SIZE)
        all_entities.extend(batch_results)

        completed = min(start + len(batch), len(texts))
        if completed % 100 == 0 or completed == len(texts):
            print(f"Processed {completed}/{len(texts)} sentences")

    ner_labels = ["O"] * len(df)
    ner_scores = [0.0] * len(df)

    for (_, group), entities in zip(groups, all_entities):
        group = group.sort_values("token_id")
        tokens = group["token"].tolist()

        bio, scores = assign_ner_labels(tokens, entities)

        for row_index, label, score in zip(group.index, bio, scores):
            ner_labels[df.index.get_loc(row_index)] = label
            ner_scores[df.index.get_loc(row_index)] = score

    df["ner_pred"] = ner_labels
    df["ner_model_score"] = ner_scores

    # English-only model: predictions, including O, require validation
    # on this English-Kokborok code-mixed dataset.
    df["ner_review_required"] = True
    df["label_source"] = "weak_lid_and_english_pretrained_ner"

    # Gold columns are not populated with automatic predictions.
    if "lid_gold" not in df.columns:
        df["lid_gold"] = ""
    if "ner_gold" not in df.columns:
        df["ner_gold"] = ""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    print("\nSilver-label generation complete.")
    print(f"Input tokens: {len(df)}")
    print(f"Output: {OUTPUT_FILE}")

    print("\nLID predictions:")
    print(df["lid_pred"].replace("", "REVIEW").value_counts().to_string())

    print("\nNER predictions:")
    print(df["ner_pred"].value_counts().to_string())

    print("\nTokens flagged for LID review:",
          int(df["lid_review_required"].sum()))
    print("Tokens flagged for NER review:",
          int(df["ner_review_required"].sum()))

    print("\nThese are model predictions, not verified gold labels.")


if __name__ == "__main__":
    main()