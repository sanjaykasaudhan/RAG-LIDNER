# Data Provenance

## RAG Corpus

The bilingual retrieval corpus is derived from the
Kokborok Digitalisation Project.

After validation and conservative cleaning, the corpus
contains 6,065 English–Kokborok aligned sentence pairs.

## Code-Mixed Corpus

The primary code-mixed corpus was provided directly by
the dataset author, Enjula Uchoi, for academic research.

The original dataset is retained without modification.

A processed copy will be created for experimentation.

## Data Processing

Processing will include:

1. Format validation
2. Missing-value detection
3. Duplicate detection
4. Tokenization
5. Annotation validation
6. Train/dev/test splitting

The original source data will remain unchanged.

## Data Privacy

No personally identifying information will be intentionally
exposed in the research outputs.

The restricted source dataset will not be publicly
redistributed unless explicit permission is obtained.