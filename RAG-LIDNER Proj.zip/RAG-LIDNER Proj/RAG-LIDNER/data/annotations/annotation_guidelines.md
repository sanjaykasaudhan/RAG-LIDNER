# English–Kokborok Code-Mixed LID + NER Annotation Guidelines

## 1. Objective

The annotation task assigns two labels to each token:

1. Language Identification (LID)
2. Named Entity Recognition (NER)

The annotation is performed on real English–Kokborok code-mixed text.

---

# 2. Language Identification Labels

## EN

English lexical item.

Example:

Nwng is my friend

is → EN
my → EN
friend → EN

---

## KOK

Kokborok lexical item.

Example:

Nwng nangni borok

Kokborok tokens are labeled KOK.

---

## MIX

Use MIX only when a single token genuinely contains
material from both languages and cannot reasonably be
segmented into independent tokens.

Do NOT use MIX merely because a sentence contains
both English and Kokborok.

---

## NE

Named entities whose language cannot be confidently
determined from the surface form.

---

## OTHER

Symbols, punctuation, emojis, URLs, mathematical symbols,
or other non-linguistic material.

---

# 3. NER Labels

Use BIO notation.

## PER

Person names.

B-PER = beginning of person entity
I-PER = continuation of person entity

Example:

B-PER Jisu
I-PER Khristo

---

## ORG

Organizations, institutions, companies, groups.

---

## LOC

Locations and geographical entities.

Examples:

Agartala
Tripura
India

---

## GPE

Countries, states, cities, and political/geographical
entities when the annotation scheme requires finer
distinction from physical locations.

---

## DATE

Dates and temporal expressions.

---

## EVENT

Named events.

---

## PRODUCT

Named products.

---

## OTHER

Named entities that do not fit the primary categories.

---

## O

Non-entity token.

---

# 4. Annotation Principle

LID and NER are independent dimensions.

A token may be:

EN + B-PER
EN + O
KOK + B-LOC
KOK + O
MIX + O

---

# 5. Tokenization

Use whitespace and punctuation-aware tokenization.

Do not alter the original spelling.

Do not lowercase the original annotation text.

Do not transliterate Kokborok.

---

# 6. Ambiguous Words

If a token is ambiguous between English and Kokborok:

1. Examine surrounding context.
2. Check the retrieval knowledge base.
3. Consult the annotator glossary.
4. If still unresolved, mark for adjudication.

---

# 7. Borrowed Words

Borrowed words should be labeled according to their
actual usage in the sentence rather than their historical
origin.

---

# 8. Named Entity Boundaries

Annotate the smallest semantically complete named entity.

For example:

New Delhi

should be:

New → B-LOC
Delhi → I-LOC

---

# 9. Annotation Quality Control

At least two annotators should independently annotate
the evaluation subset.

Disagreements should be adjudicated by a third reviewer
or consensus discussion.

Inter-annotator agreement should be reported.

Recommended metrics:

- Cohen's kappa
- token-level agreement
- entity-level F1 agreement