# Author-Provided English–Kokborok Code-Mixed Dataset

## Dataset Name

Kokborok Code-mixed dataset

## Source

Dataset provided directly by:

Enjula Uchoi

## Research Project

Joint Language Identification and Named Entity Recognition
in English–Kokborok Code-Mixed Text Using
Retrieval-Augmented Large Language Models

## Dataset Type

English–Kokborok code-mixed/code-switched text.

## Number of Entries

2,000 numbered entries in the provided file.

## Acquisition

The dataset was received directly from the dataset author
for academic research.

## Original File

Kokborok Code-mixed dataset.txt

## Original Data

The original file must not be modified.

All preprocessing will be performed on a separate copy.

## Intended Use

Academic research and experimentation.

## Citation

The associated research work and dataset provider will be
properly acknowledged and cited in the research paper.

## Redistribution

The dataset will NOT be redistributed publicly unless
explicit permission is obtained.

## Privacy

Any restrictions specified by the dataset provider will
be respected.

## Date Received

2026-08-20